function article_printer() {

}