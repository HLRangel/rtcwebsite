function build_query_link() {
    const padtext = document.getElementById("notepad-textarea");
    if(padtext != null) {
        let url = new URL(window.location.href);
        
        url.search = new URLSearchParams({
                        data: LZString.compressToBase64(padtext.value).toString()
                    }).toString();

        return url.toString();
    }

    return null;
}

function save_notepad() {
    const link = build_query_link();
    const out = document.getElementById("notepad-results");

    if(link != null && out != null) {
        out.style.display = "block";
        out.value = link;
    }
}

function spawn_notepad() {
    const pad = document.querySelector("notepad");

    if(pad != null) {
        pad.innerHTML = `
        <h3 id="notepad-title">Editing pad</h3>
        <div class="notepad-window">
            <textarea id="notepad-textarea" class="notepad-pad" rows="10"></textarea>

            <div class="save-copy">
                <p><a href="#" class="notepad-save" onclick="save_notepad();">Save Notepad</a></p>

                <input type="text" id="notepad-results" readonly="readonly">
            </div>
        </div>
        `;

        const padlink = document.getElementById("notepad-results");

        padlink.style.display = "none";
    }
}

function data_into_pad(data) {
    const padtext = document.getElementById("notepad-textarea");

    if(padtext != null) {
        padtext.value = data;
    }
}

function populate_notepad(){
    spawn_notepad();
    const url = new URLSearchParams(window.location.search);

    if(url.has("data")) {
        data_into_pad(LZString.decompressFromBase64(url.get("data")).toString());
    }
}

function notepad() {
    populate_notepad();
}

notepad();